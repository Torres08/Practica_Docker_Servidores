<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Práctica SWAP - Juan Luis Jiménez Laredo</title>
</head>
<body>
    <h1>Práctica SWAP - Juan Luis Jiménez Laredo</h1>
    <p>La dirección IP del servidor es: <?php echo $_SERVER['SERVER_ADDR']; ?></p>
</body>
</html>
